package com.example.commerce.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "cart_items")
public class CartItem {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@ManyToOne
	@JoinColumn(name = "cart_id")
	private Cart cart;
	
	@ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;
	
	private int cquantity;

	public CartItem(int id, Cart cart, Product product, int cquantity) {
		super();
		this.id = id;
		this.cart = cart;
		this.product = product;
		this.cquantity = cquantity;
	}

	public CartItem() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getCquantity() {
		return cquantity;
	}

	public void setCquantity(int cquantity) {
		this.cquantity = cquantity;
	}
	
	
	

}
